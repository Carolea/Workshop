<?php require_once"modeles/modeles.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="vues/css/style.css">
	<title>Trombino-PoleS</title>
</head>
<body style="background-image: url(modeles/img/background.jpg);">

  <?php include "vues/main-page.php"; ?>

</body>
</html>
